import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import apiRouter from "./backend/index";
import db from "./backend/db";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({
  verify: (req, _res, buf) => {
    // Captured for webhook signature verification (backend/routes/webhooks.ts),
    // which must check the exact bytes sent, not a re-serialized copy of req.body.
    (req as any).rawBody = buf.toString('utf8');
  },
}));

// REST API backend (migrated from the Suremart PHP app): auth, products,
// categories, orders, vendors, users, delivery zones, logistics providers,
// support chats. See backend/index.ts for the full route list.
app.use("/api", apiRouter);

// Initialize Gemini SDK with telemetry and fallback state
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini API initialized successfully.");
  } catch (err) {
    console.error("Failed to initialize Gemini API:", err);
  }
} else {
  console.warn("GEMINI_API_KEY is not configured. Falling back to rule-based simulation engine.");
}

// Helper to sanitize Gemini response text
function cleanMarkdownJson(text: string): string {
  let cleaned = text.trim();
  if (cleaned.startsWith("```json")) {
    cleaned = cleaned.substring(7);
  } else if (cleaned.startsWith("```")) {
    cleaned = cleaned.substring(3);
  }
  if (cleaned.endsWith("```")) {
    cleaned = cleaned.substring(0, cleaned.length - 3);
  }
  return cleaned.trim();
}

// API: Health Check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    geminiEnabled: !!ai
  });
});

// API: Get Personalized Product Recommendations
app.post("/api/gemini/recommend", async (req, res) => {
  const { persona, interests, budget, products } = req.body;

  if (!persona) {
    return res.status(400).json({ error: "persona is required" });
  }

  const prompt = `You are TradeEase AI, a brilliant personal shopping assistant specializing in the Nigerian marketplace.
A user with the shopping persona "${persona}" and interest tags [${interests?.join(", ")}] with a budget of ₦${budget || "any"} is seeking recommendations.

Here is the current TradeEase marketplace products inventory:
${JSON.stringify(products?.map((p: any) => ({ id: p.id, title: p.title, price: p.price, category: p.category, description: p.description })))}

Analyze this inventory. Select the top 3-4 products that fit this user's persona, interests, and budget best.
Explain *why* each product is perfectly personalized for them. Also suggest a dynamic personalized shopping advice tip.

You must respond with a valid JSON array of objects conforming exactly to this structure:
{
  "recommendations": [
    {
      "productId": "id-of-the-product",
      "personalizationReason": "Why this matches your exact interest and budget specifically."
    }
  ],
  "advice": "A custom paragraph of shopping advice tailored to their profile (referencing local Nigerian trends, state specifics, saving tips, etc.)",
  "aiPersonaName": "e.g., Tech Guru, Fashionista Scout, Budget Strategist, Naija Food Connoisseur"
}`;

  try {
    if (ai) {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          systemInstruction: "You are an expert personalized retail AI assistant. Format your output strictly as compact JSON.",
        }
      });

      const text = response.text || "";
      const parsed = JSON.parse(cleanMarkdownJson(text));
      return res.json(parsed);
    }
  } catch (error) {
    console.error("Gemini recommends error:", error);
  }

  // Fallback engine if Gemini key is missing or fails
  console.log("Using rule-based simulation for recommendations...");
  const budgetVal = Number(budget) || 9999999;
  const matches = (products || []).filter((p: any) => {
    const isUnderBudget = p.price <= budgetVal;
    const categoryMatches = (interests || []).some((interest: string) => 
      p.category?.toLowerCase().includes(interest.toLowerCase()) || 
      p.title?.toLowerCase().includes(interest.toLowerCase())
    );
    return isUnderBudget && (categoryMatches || Math.random() > 0.6);
  }).slice(0, 3);

  const finalRecommendations = matches.map((p: any) => ({
    productId: p.id,
    personalizationReason: `Selected because it matches your preferred price point and fits with your ${persona.toLowerCase()} lifestyle.`
  }));

  res.json({
    recommendations: finalRecommendations.length > 0 ? finalRecommendations : (products || []).slice(0, 3).map((p: any) => ({
      productId: p.id,
      personalizationReason: "Selected as a curated high-rating essential matching your marketplace budget."
    })),
    advice: `Since you're shopping with a ${persona} mindset, we recommend prioritizing highly durable items. Consider pairing your picks with certified TradeEase shipping options to optimize deliveri tracking inside Nigeria.`,
    aiPersonaName: persona === "budget" ? "Naija Budget Strategist" : "Premium Curator Assistant"
  });
});

// API: Dynamic AI Shopping Copilot Chat
app.post("/api/gemini/chat", async (req, res) => {
  const { messages, currentPersona, currentPreferences, products } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "messages array is required" });
  }

  // Formulate prompt context
  const latestMessage = messages[messages.length - 1]?.content || "";
  const previousTurns = messages.slice(0, messages.length - 1).map((m: any) => 
    `${m.role === "user" ? "Buyer" : "Assistant"}: ${m.content}`
  ).join("\n");

  const systemPrompt = `You are TradeEase AI Copilot, a helpful, witty, and personalized shopping assistant for TradeEase - Nigeria's elite multivendor marketplace.
User Persona: ${currentPersona || "General Shopper"}
Preferences: ${JSON.stringify(currentPreferences || {})}
Inventory of active products:
${JSON.stringify(products?.slice(0, 15).map((p: any) => ({ id: p.id, title: p.title, price: p.price, category: p.category })))}

Provide an elegant, helpful response to the user's latest query. Make references to the items in our list if appropriate. Be friendly, polite, utilize authentic local context (like naira prices ₦, shipping via local state capitals, or common Nigerian terms) when helpful. Keep answers concise, highly polished, and clear.`;

  try {
    if (ai) {
      const chatPrompt = `${previousTurns}\nBuyer: ${latestMessage}\nAssistant:`;
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: chatPrompt,
        config: {
          systemInstruction: systemPrompt,
        }
      });

      return res.json({ reply: response.text });
    }
  } catch (error) {
    console.error("Gemini chat error:", error);
  }

  // Fallback dialogue responder
  const replyText = `Hello! I am your TradeEase personalized copilot. I scanned our active inventory for your profile (${currentPersona || "General"}). If you're looking for recommendations, try checking out products like our rechargeable solar fans or premium fashion items. How else can I assist with your ₦ budgeting today?`;
  res.json({ reply: replyText });
});

// API: Vendor Listing Optimizer
app.post("/api/gemini/vendor-optimize", async (req, res) => {
  const { title, description, category, price } = req.body;

  if (!title) {
    return res.status(400).json({ error: "title is required" });
  }

  const prompt = `You are an expert digital marketing content writer for Nigerian merchants.
Optimize the following TradeEase product listing to attract high conversions:
Original Title: ${title}
Original Description: ${description || "None provided"}
Category: ${category || "General"}
Target List Price: ₦${price || "TBD"}

Tasks:
1. Write a highly persuasive, professional SEO-optimized Title.
2. Formulate a rich, engaging, structured Description emphasizing key selling points, durability, and target benefits for Nigerian households or professionals. Include 3 bullet points of highlights.
3. Suggest a 1-sentence catchy social media pitch for Instagram or WhatsApp Business status.

Respond STRICTLY with a valid JSON object conforming exactly to this schema:
{
  "optimizedTitle": "New Beautiful Title",
  "optimizedDescription": "Elegantly written description with benefits...",
  "socialMediaPitch": "Captivating pitch text for WhatsApp/Insta..."
}`;

  try {
    if (ai) {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          systemInstruction: "You are an elite e-commerce listing optimizer. Produce only valid JSON.",
        }
      });

      const text = response.text || "";
      const parsed = JSON.parse(cleanMarkdownJson(text));
      return res.json(parsed);
    }
  } catch (error) {
    console.error("Gemini vendor optimize error:", error);
  }

  // Fallback optimization
  res.json({
    optimizedTitle: `★ Premium ${title} (Authentic Quality Guarantee)`,
    optimizedDescription: `${description || "Elegantly crafted item designed for premium performance."}\n\nKey Highlights:\n• High durability and excellent materials\n• Great value-for-money pricing verified by TradeEase\n• Quick delivery to all Nigerian coordinates`,
    socialMediaPitch: `✨ Upgrade your lifestyle with the pure quality of our certified "${title}" today! Best rates guaranteed. DM to order now! 📲`
  });
});

// Setup Vite & static serving
async function startServer() {
  // First-boot convenience: if this is a brand new database (no admin
  // account exists yet — e.g. a fresh deploy with an empty volume), seed it
  // automatically with the app's starting data, instead of requiring a
  // manual `npm run seed` step on the host.
  try {
    const adminCount = (db.prepare('SELECT COUNT(*) as c FROM admins').get() as any).c;
    if (adminCount === 0) {
      console.log('No admin account found — seeding the database with starting data...');
      const { runSeed } = await import('./backend/seed');
      runSeed();
      console.log('Database seeded. Admin login: admin@tradeease.ng / admin123');
    }
  } catch (err) {
    console.error('Auto-seed check failed (continuing without seeding):', err);
  }

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server middleware mounted.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get(/^\/(admin|backoffice)$/, (req, res) => {
      res.sendFile(path.join(distPath, 'admin.html'));
    });
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Serving static product bundle from /dist.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
